(() => {
  var __defProp = Object.defineProperty;
  var __export = (target, all) => {
    for (var name in all)
      __defProp(target, name, { get: all[name], enumerable: true });
  };

  // src/main-world/foundryAdapter.js
  var foundryAdapter_exports = {};
  __export(foundryAdapter_exports, {
    TARGET_VERSION: () => TARGET_VERSION,
    adapterStatus: () => adapterStatus,
    assertGM: () => assertGM,
    createAdapter: () => createAdapter,
    disable: () => disable,
    enable: () => enable,
    isGM: () => isGM,
    relinquish: () => relinquish,
    roll: () => roll,
    runAction: () => runAction,
    validateScenes: () => validateScenes
  });
  var TARGET_VERSION = 14;
  var adapterStatus = "Foundry v14 adapter; remote non-playlist stop is unsupported";
  function createAdapter({ getGame = () => globalThis.game, getFoundry = () => globalThis.foundry, getConfig = () => globalThis.CONFIG, getStorage = () => globalThis.localStorage } = {}) {
    let originalVolume, enabled = false;
    const volumeOwner = crypto.randomUUID();
    const volumeKey = () => `stagehand:playlist-volume:${getGame()?.world?.id ?? "world"}:${getGame()?.user?.id ?? "user"}`;
    function baseline() {
      try {
        const value = JSON.parse(getStorage()?.getItem(volumeKey()) ?? "null");
        return Number.isFinite(value?.volume) && value.volume > 0 ? value : void 0;
      } catch {
        return void 0;
      }
    }
    function retain(volume) {
      try {
        getStorage()?.setItem(volumeKey(), JSON.stringify({ volume, owner: volumeOwner }));
      } catch {
      }
    }
    const images = /* @__PURE__ */ new Set();
    const isGM2 = () => getGame()?.user?.isGM === true;
    function assertGM2() {
      if (!isGM2()) throw new Error("Stagehand requires a GM.");
    }
    function assertVersion() {
      if (Number(String(getGame()?.version).split(".")[0]) !== TARGET_VERSION) throw new Error("Stagehand requires Foundry v14.");
    }
    function requireEnabled() {
      assertGM2();
      assertVersion();
      if (!enabled) throw new Error("Stagehand is disabled.");
    }
    function find(collection, action, kind) {
      const document2 = action.id ? collection?.get(action.id) : collection?.getName(action.name);
      if (!document2) throw new Error(`${kind} not found: ${action.id ?? action.name}`);
      return document2;
    }
    async function enable2() {
      assertGM2();
      assertVersion();
      if (enabled) return;
      const settings = getGame().settings, config = settings?.settings?.get("core.globalPlaylistVolume");
      if (config?.scope !== "client") throw new Error("Cannot verify a client-local core.globalPlaylistVolume setting.");
      const volume = settings.get("core", "globalPlaylistVolume");
      if (!Number.isFinite(volume)) throw new Error("Invalid Foundry playlist volume.");
      originalVolume = volume > 0 ? volume : baseline()?.volume;
      if (originalVolume !== void 0) retain(originalVolume);
      await settings.set("core", "globalPlaylistVolume", 0);
      enabled = true;
    }
    async function disable2() {
      if (!enabled) return;
      if (originalVolume !== void 0 && (!baseline() || baseline().owner === volumeOwner)) {
        await getGame().settings.set("core", "globalPlaylistVolume", originalVolume);
        try {
          getStorage()?.removeItem(volumeKey());
        } catch {
        }
      }
      enabled = false;
      originalVolume = void 0;
    }
    function relinquish2() {
      enabled = false;
      originalVolume = void 0;
    }
    async function stopAll() {
      const game = getGame();
      const results = await Promise.allSettled([...game.playlists.playing].map((playlist) => playlist.stopAll()));
      const local = await Promise.allSettled([...game.audio.playing.values()].map((sound) => sound.stop()));
      const error = [...results, ...local].find((result) => result.status === "rejected");
      if (error) throw error.reason;
      return { warning: "Playlist audio stopped for everyone. Remote non-playlist sounds cannot be stopped through the documented public API." };
    }
    async function runAction2(action, { signal } = {}) {
      requireEnabled();
      signal?.throwIfAborted();
      const game = getGame(), foundry = getFoundry();
      switch (action.type) {
        case "scene": {
          const scene = find(game.scenes, action, "Scene");
          if (scene.active) return { already: true };
          await scene.activate();
          return {};
        }
        case "playlist":
          await find(game.playlists, action, "Playlist").playAll();
          return {};
        case "music": {
          const playlist = find(game.playlists, action, "Playlist");
          if (playlist.playing) return {};
          await Promise.all([...game.playlists.playing].filter((p) => p.id !== playlist.id).map((p) => p.stopAll()));
          await playlist.playAll();
          return {};
        }
        case "macro": {
          const macro = find(game.macros, action, "Macro");
          if (action.scope === void 0) await macro.execute();
          else await macro.execute(action.scope);
          return {};
        }
        case "initiative": {
          const combat = game.combat;
          if (!combat) throw new Error("No fight running.");
          const who = String(action.who).trim().toLowerCase().replace(/^the /, "");
          const all = [...combat.combatants], tiers = [(n) => n === who, (n) => n.startsWith(who), (n) => n.includes(who)];
          let hits = [];
          for (const test of tiers) {
            hits = all.filter((c) => test(String(c.name ?? "").toLowerCase()));
            if (hits.length) break;
          }
          if (hits.length !== 1) throw new Error(hits.length ? `More than one combatant matches "${action.who}".` : `No combatant named "${action.who}".`);
          await combat.setInitiative(hits[0].id, action.value);
          return {};
        }
        case "sound": {
          const playlist = find(game.playlists, { name: action.playlist, id: action.playlistId }, "Playlist");
          await playlist.playSound(find(playlist.sounds, action, "Track"));
          return {};
        }
        case "stop_all":
          return stopAll();
        case "oneshot": {
          if (!action.src) throw new Error("Missing one-shot source.");
          const volume = action.volume ?? 1;
          if (!Number.isFinite(volume) || volume < 0 || volume > 1) throw new Error("Invalid one-shot volume.");
          foundry.audio.AudioHelper.play({ src: action.src, volume, loop: false, autoplay: true, channel: "music" }, true);
          return {};
        }
        case "handout": {
          if (!action.src) throw new Error("Missing handout source.");
          const title = action.title ?? action.label ?? action.id ?? "Handout";
          const image = new foundry.applications.apps.ImagePopout({ src: action.src, window: { title } });
          images.add(image);
          image.shareImage({ image: action.src, title, showTitle: true });
          return {};
        }
        case "hide_handout": {
          await Promise.all([...images].map((image) => image.close()));
          images.clear();
          return { warning: "Closed Stagehand image windows on this client. The public API does not expose remote image closing." };
        }
        case "wait": {
          if (!Number.isFinite(action.ms) || action.ms < 0 || action.ms > 6e4) throw new Error("Invalid wait duration.");
          await new Promise((resolve, reject) => {
            const abort = () => {
              clearTimeout(timer);
              reject(signal.reason);
            };
            const timer = setTimeout(() => {
              signal?.removeEventListener("abort", abort);
              resolve();
            }, action.ms);
            signal?.addEventListener("abort", abort, { once: true });
          });
          return {};
        }
        default:
          throw new Error(`Unsupported Foundry action: ${action.type}`);
      }
    }
    async function roll2(formula) {
      requireEnabled();
      const Roll = getFoundry().dice.Roll;
      if (!Roll.validate(formula)) throw new Error("Not a roll.");
      const modes = getConfig()?.ChatMessage?.modes ?? {}, mode = ["self", "selfroll"].find((k) => k in modes);
      const result = await new Roll(formula).evaluate({ allowInteractive: false });
      await result.toMessage({ flavor: "Stagehand", whisper: [getGame().user.id], blind: false }, mode ? { messageMode: mode } : {});
      return { total: result.total, result: result.result };
    }
    async function validateScenes2(sheet) {
      if (!isGM2()) return [];
      const errors = [];
      for (const cue of sheet.cues ?? []) for (const action of cue.actions ?? []) if (action.type === "scene") {
        try {
          find(getGame().scenes, action, "Scene");
        } catch (error) {
          errors.push(error.message);
        }
      }
      if (sheet.black_scene) {
        try {
          find(getGame().scenes, { name: sheet.black_scene }, "Black scene");
        } catch (error) {
          errors.push(error.message);
        }
      }
      return [...new Set(errors)];
    }
    return { isGM: isGM2, assertGM: assertGM2, enable: enable2, disable: disable2, relinquish: relinquish2, runAction: runAction2, roll: roll2, validateScenes: validateScenes2 };
  }
  var adapter = createAdapter();
  var { isGM, assertGM, enable, disable, relinquish, runAction, roll, validateScenes } = adapter;

  // src/main-world/tts.js
  var options = {};
  function configureTTS(value) {
    options = value;
  }
  function speak(text) {
    if (!globalThis.speechSynthesis) return;
    speechSynthesis.cancel();
    const utterance = new SpeechSynthesisUtterance(text);
    utterance.rate = options.rate ?? 1;
    utterance.lang = options.lang ?? "en-US";
    const voice = speechSynthesis.getVoices().find((v) => v.voiceURI === options.voice);
    if (voice) utterance.voice = voice;
    speechSynthesis.speak(utterance);
  }

  // src/main-world/hotkeys.js
  function matchesKey(event, shortcut) {
    const parts = shortcut.split("+"), key = parts.pop();
    return event.key.toLowerCase() === key.toLowerCase() && event.ctrlKey === parts.includes("Ctrl") && event.altKey === parts.includes("Alt") && event.shiftKey === parts.includes("Shift") && event.metaKey === parts.includes("Meta");
  }
  function bindHotkeys(getConfig, callbacks, target = window) {
    const down = (event) => {
      if (event.repeat || event.isComposing) return;
      const { options: options2, sheet } = getConfig();
      if (/^(INPUT|TEXTAREA|SELECT)$/.test(event.target?.tagName) || event.target?.isContentEditable) return;
      if (matchesKey(event, options2.pttKey)) {
        event.preventDefault();
        callbacks.log?.("ptt-down", { key: options2.pttKey });
        callbacks.start();
        return;
      }
      const cue = [...sheet.cues ?? [], ...sheet.handouts ?? []].find((c) => c.hotkey && matchesKey(event, c.hotkey));
      if (cue) {
        event.preventDefault();
        callbacks.log?.("hotkey", { cueId: cue.id });
        callbacks.cue(cue.id);
      }
    };
    const up = (event) => {
      if (event.key.toLowerCase() === getConfig().options.pttKey.split("+").pop().toLowerCase()) {
        event.preventDefault();
        callbacks.log?.("ptt-up", { key: getConfig().options.pttKey });
        callbacks.stop();
      }
    };
    target.addEventListener("keydown", down);
    target.addEventListener("keyup", up);
    target.addEventListener("blur", callbacks.stop);
    return () => {
      target.removeEventListener("keydown", down);
      target.removeEventListener("keyup", up);
      target.removeEventListener("blur", callbacks.stop);
    };
  }

  // src/main-world/speech.js
  function createSpeech({ getOptions, emit, speak: speak2, allowed, log = () => {
  } }) {
    let recognition, active = false, timer, alternatives = [], aborted = false, toggleMode = false, emitted = false;
    const finalize = () => {
      if (!aborted && !emitted && alternatives.length) {
        emitted = true;
        emit({ type: "transcript", alternatives });
      }
    };
    const stop = () => {
      active = false;
      clearTimeout(timer);
      if (recognition) recognition.stop();
      else finalize();
    };
    const abort = () => {
      aborted = true;
      active = false;
      clearTimeout(timer);
      recognition?.abort();
    };
    const resetTimer = () => {
      clearTimeout(timer);
      timer = setTimeout(stop, 6e3);
    };
    function start(toggle = false) {
      if (active || !allowed()) return;
      const Recognition = globalThis.webkitSpeechRecognition;
      if (!Recognition) {
        emit({ type: "status", status: "error", mic: false, error: "Chrome speech recognition is unavailable." });
        speak2("Mic unavailable.");
        return;
      }
      recognition = new Recognition();
      recognition.lang = getOptions().lang ?? "en-US";
      recognition.interimResults = true;
      recognition.maxAlternatives = 5;
      recognition.continuous = true;
      alternatives = [];
      aborted = false;
      active = true;
      toggleMode = toggle;
      emitted = false;
      recognition.onresult = (event) => {
        const results = Array.from(event.results);
        log("speech-result", { transcript: results.map((r) => r[0].transcript).join(" ") });
        emit({ type: "live", text: results.map((r) => r[0].transcript).join(" ") });
        const finals = results.filter((r) => r.isFinal);
        if (finals.length) alternatives = Array.from({ length: Math.min(5, Math.max(...finals.map((r) => r.length))) }, (_, i) => finals.map((r) => (r[i] ?? r[0]).transcript).join(" "));
        if (toggle) resetTimer();
      };
      recognition.onerror = (event) => {
        log("speech-error", { error: event.error });
        aborted = true;
        const text = { "no-speech": "Didn't catch that.", network: "Speech network error.", "not-allowed": "Mic blocked." }[event.error] ?? "Mic error.";
        emit({ type: "status", status: "error", mic: false, error: text });
        speak2(text);
      };
      recognition.onend = () => {
        log("speech-end");
        recognition = null;
        clearTimeout(timer);
        emit({ type: "status", status: aborted ? "error" : "idle", mic: false });
        if (toggleMode || !active || aborted) {
          active = false;
          finalize();
        }
      };
      recognition.onstart = () => {
        log("speech-start");
        emit({ type: "status", status: "listening", mic: true });
        try {
          const ctx = new AudioContext(), osc = ctx.createOscillator(), gain = ctx.createGain();
          gain.gain.value = 0.025;
          osc.connect(gain).connect(ctx.destination);
          osc.start();
          osc.stop(ctx.currentTime + 0.045);
          osc.onended = () => ctx.close();
        } catch {
        }
      };
      try {
        recognition.start();
        if (toggle) resetTimer();
      } catch (error) {
        log("speech-error", { error: error.message });
        active = false;
        emit({ type: "status", status: "error", mic: false, error: error.message });
      }
    }
    return { start, stop, abort, toggle: () => active ? stop() : start(true) };
  }

  // src/shared/timeout.js
  async function withTimeout(operation, ms = 8e3) {
    let timer;
    try {
      return await Promise.race([operation, new Promise((_, reject) => {
        timer = setTimeout(() => reject(new Error("Foundry action timed out. Check the connection.")), ms);
      })]);
    } finally {
      clearTimeout(timer);
    }
  }

  // src/main-world/runtime.js
  function startStagehand({ win, doc, adapter: adapter2, speak: speak2, configureTTS: configureTTS2, now = Date.now, setPoll = setInterval, clearPoll = clearInterval, sid = crypto.randomUUID() }) {
    const tag = "stagehand-v1", startedAt = now();
    let options2 = { pttKey: "F13" }, sheet = { cues: [] }, active = false, superseded = false, closed = false, unbind, lastHeartbeat = now(), timedOut = false, generation = 0, controller = new AbortController(), execution = Promise.resolve(), configuring = Promise.resolve(), ownerEpoch = 0;
    const emit = (payload) => win.postMessage({ tag, direction: "to-extension", payload: { ...payload, sid } }, win.location.origin);
    const log = (ev, details = {}) => emit({ type: "log", ev, details });
    const speech = createSpeech({ getOptions: () => options2, emit, speak: speak2, log, allowed: () => active && adapter2.isGM() && !closed });
    log("load", { version: String(win.game?.version ?? "not-ready"), isGM: adapter2.isGM(), visibility: doc.visibilityState });
    function bind() {
      unbind?.();
      unbind = bindHotkeys(() => ({ options: options2, sheet }), { start: () => speech.start(), stop: speech.stop, cue: (cueId) => emit({ type: "transcript", alternatives: [], cueId }), log }, win);
    }
    function cancel() {
      active = false;
      generation++;
      controller.abort();
      controller = new AbortController();
      execution = Promise.resolve();
      speech.abort();
      unbind?.();
      unbind = void 0;
    }
    async function deactivate(reason, restore = true) {
      log("deactivate", { reason });
      cancel();
      if (restore) {
        try {
          await adapter2.disable();
          log("disable", { reason, ok: true });
        } catch (error) {
          log("disable", { reason, ok: false, error: error.message });
        }
      } else {
        adapter2.relinquish();
        superseded = true;
      }
      emit({ type: "status", status: reason === "newer-tab" ? "inactive" : "idle", mic: false, connected: false });
    }
    function requestConnection(reason) {
      if (closed || !adapter2.isGM()) return;
      log("reconnect", { reason, elapsedMs: now() - lastHeartbeat });
      emit({ type: "ready", startedAt, isGM: true, adapter: adapter2.adapterStatus });
      emit({ type: "ping" });
    }
    async function measure(type, name, run) {
      const start = now();
      try {
        const result = await run();
        log("action", { type, name, duration: now() - start, ok: true });
        return result;
      } catch (error) {
        log("action", { type, name, duration: now() - start, ok: false, error: error.message });
        throw error;
      }
    }
    async function receive(event) {
      if (event.source !== win || event.origin !== win.location.origin || event.data?.tag !== tag || event.data.direction !== "to-page") return;
      const msg = event.data.payload;
      if (!msg) return;
      if (["configure", "deactivate"].includes(msg.type) && Number.isFinite(msg.epoch)) {
        if (msg.epoch < ownerEpoch) {
          log("stale-control", { type: msg.type, reason: "newer-owner" });
          return;
        }
        ownerEpoch = msg.epoch;
      }
      if (msg.type === "shutdown") {
        closed = true;
        await deactivate(msg.reason ?? "extension-off");
        return;
      }
      if (msg.type === "deactivate") {
        if (superseded && !active) return;
        await deactivate(msg.reason ?? "newer-tab", false);
        return;
      }
      if (closed || !adapter2.isGM()) return;
      if (msg.type === "heartbeat") {
        lastHeartbeat = now();
        timedOut = false;
        return;
      }
      if (msg.type === "configure") {
        log("configure");
        options2 = msg.options;
        sheet = msg.sheet;
        configureTTS2(options2);
        const ownGeneration2 = generation;
        configuring = configuring.then(async () => {
          if (closed || ownGeneration2 !== generation) return;
          try {
            await withTimeout(adapter2.enable());
            if (closed || ownGeneration2 !== generation) {
              if (superseded) adapter2.relinquish();
              else await adapter2.disable();
              return;
            }
            active = true;
            superseded = false;
            lastHeartbeat = now();
            timedOut = false;
            bind();
            log("enable", { ok: true });
            emit({ type: "status", status: "idle", mic: false, sceneErrors: await adapter2.validateScenes(sheet) });
          } catch (error) {
            active = false;
            log("enable", { ok: false, error: error.message });
            emit({ type: "status", status: "error", error: error.message, mic: false });
          }
        });
        await configuring;
        return;
      }
      if (msg.type === "speak") {
        if (active) speak2(msg.text);
        return;
      }
      if (msg.type === "toggle") {
        speech.toggle();
        return;
      }
      if (msg.type !== "execute") return;
      const command = msg.command;
      if (command.urgent) {
        controller.abort();
        controller = new AbortController();
        generation++;
        execution = Promise.resolve();
      }
      const ownGeneration = generation, signal = controller.signal;
      execution = execution.then(async () => {
        try {
          if (ownGeneration !== generation) return;
          if (!active) throw new Error("Stagehand is inactive in this tab.");
          if (command.type === "roll") {
            const result = await measure("roll", command.label ?? command.formula, () => withTimeout(adapter2.roll(command.formula)));
            emit({ type: "result", total: result.total, named: command.named, spoken: `${command.formula}: ${result.total}.`, detail: `${command.formula} = ${result.result} = ${result.total}` });
          } else if (command.type === "hide_handout") {
            const result = await measure("hide_handout", "", () => withTimeout(adapter2.runAction({ type: "hide_handout" }, { signal })));
            emit({ type: "result", spoken: "Handout hidden.", detail: result.warning });
          } else {
            let already = false;
            const warnings = [], errors = [];
            for (const action of command.actions ?? []) {
              try {
                const result = await measure(action.type, action.name ?? action.id ?? action.src ?? "", () => withTimeout(adapter2.runAction(action, { signal }), action.type === "wait" ? action.ms + 1e3 : 8e3));
                already = result?.already || already;
                if (result?.warning) warnings.push(result.warning);
              } catch (error) {
                if (!command.urgent) throw error;
                errors.push(error.message);
              }
            }
            emit({ type: "result", cueId: command.cueId, spoken: already ? "Already there." : command.label, detail: [command.label, ...warnings].join("\n"), ...errors.length ? { error: errors.join("\n") } : {} });
          }
        } catch (error) {
          if (!signal.aborted) emit({ type: "result", cueId: command.cueId, error: error.message });
        }
      });
      await execution;
    }
    async function poll() {
      if (closed) return;
      if (!adapter2.isGM()) {
        if (active) await deactivate("not-gm");
        return;
      }
      if (active) {
        if (!doc.hidden && now() - lastHeartbeat > 45e3 && !timedOut) {
          timedOut = true;
          log("deactivate", { reason: "heartbeat-timeout", elapsedMs: now() - lastHeartbeat });
          emit({ type: "status", status: "reconnecting", mic: false });
          requestConnection("heartbeat-timeout");
        }
        emit({ type: "ping" });
      } else if (!superseded) requestConnection("poll");
    }
    const visibility = () => {
      log("visibility", { visibility: doc.visibilityState });
      if (!doc.hidden) requestConnection("visible");
    };
    win.addEventListener("message", (event) => {
      void receive(event).catch((error) => log("page-error", { error: error.message }));
    });
    win.addEventListener("focus", () => {
      log("focus");
      if (!doc.hidden) requestConnection("focus");
    });
    win.addEventListener("blur", () => log("blur"));
    doc.addEventListener("visibilitychange", visibility);
    const interval = setPoll(() => {
      void poll().catch((error) => log("page-error", { error: error.message }));
    }, 2e3);
    win.addEventListener("pagehide", () => {
      closed = true;
      clearPoll(interval);
      void deactivate("pagehide");
    });
    requestConnection("load");
    return { receive, poll, visibility, shutdown: async () => {
      closed = true;
      clearPoll(interval);
      await deactivate("extension-off");
    } };
  }

  // src/main-world/index.js
  if (!window.__stagehandInstalled) {
    window.__stagehandInstalled = true;
    startStagehand({ win: window, doc: document, adapter: foundryAdapter_exports, speak, configureTTS });
  }
})();
